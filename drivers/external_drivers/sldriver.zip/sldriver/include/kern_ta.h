#ifndef _KERN_TA_H_
#define _KERN_TA_H_

int ta_create_entry_point( void );
int ep_foo(void);
int kern_ta_foo(void);
#endif
