#include "include/hip.h"
#include <linux/types.h>

inline bool valid(struct hip_t *ptr)
{ //return ptr->_hip_identifier == (ptr->V_ID = valid_identifier); }
	return 0;
}

inline uint16_t kernel_version(struct hip_t *ptr)
{ return ptr->_kernel_version; }

inline uint16_t api_revision(struct hip_t *ptr)
{ return ptr->_api_revision; }

inline bool feature_em(struct hip_t *ptr)
{ return ptr->_feature_em; }

inline bool feature_perf_sample(struct hip_t *ptr)
{ return ptr->_feature_perf_sample; }

inline bool feature_perf_trace(struct hip_t *ptr)
{ return ptr->_feature_perf_trace; }

inline bool feature_perf_path(struct hip_t *ptr)
{ return ptr->_feature_perf_path; }

inline bool feature_eptad(struct hip_t *ptr)
{ return ptr->_feature_eptad; }

inline bool feature_cachesim(struct hip_t *ptr)
{ return ptr->_feature_cachesim; }

inline unsigned num_cpus(struct hip_t *ptr)
{ return ptr->_num_cpus; }

